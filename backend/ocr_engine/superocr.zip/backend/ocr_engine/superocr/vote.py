from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass
from statistics import mean
from typing import Callable, Mapping

from .types import Reading


@dataclass(frozen=True)
class VoteOutcome:
    value: str | None
    agreement: float
    confidence: float
    votes: int
    conflict: bool


def vote(readings: list[Reading], normalize: Callable[[str], str | None],
         weights: Mapping[str, float]) -> VoteOutcome:
    """
    Group readings by canonical value; invalid readings vote for nothing but
    still count in the denominator, so noisy fields score low agreement.
    `conflict` = a different valid value has at least half the winner's weight.
    """
    total = sum(weights.get(r.engine, 1.0) for r in readings)
    tally: dict[str, list] = defaultdict(lambda: [0.0, []])
    for r in readings:
        v = normalize(r.text) if r.text else None
        if v is None:
            continue
        tally[v][0] += weights.get(r.engine, 1.0)
        tally[v][1].append(r.conf)
    if not tally or total == 0:
        return VoteOutcome(None, 0.0, 0.0, 0, False)

    ranked = sorted(tally.items(), key=lambda kv: (kv[1][0], mean(kv[1][1])), reverse=True)
    best, (bw, confs) = ranked[0]
    agreement = bw / total
    conflict = len(ranked) > 1 and ranked[1][1][0] >= 0.5 * bw
    return VoteOutcome(best, agreement, mean(confs) * agreement, len(confs), conflict)
