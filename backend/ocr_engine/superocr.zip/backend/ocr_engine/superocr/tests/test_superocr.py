import pytest

from backend.ocr_engine.superocr.fields import normalize_date, normalize_name, normalize_zw_id
from backend.ocr_engine.superocr.types import Reading
from backend.ocr_engine.superocr.vote import vote

W = {"tesseract": 1.0, "paddle": 1.0}


def test_id_dollar_read_as_S():
    assert normalize_zw_id("63-2316316 $ 50") == "63-2316316 S 50"


def test_id_without_suffix_is_rejected_not_truncated():
    assert normalize_zw_id("63-2316316 S") is None


def test_id_position_aware_repair():
    assert normalize_zw_id("63-23I63I6 S 5O") == "63-2316316 S 50"


def test_id_separators_irrelevant():
    assert normalize_zw_id("632316316S50") == "63-2316316 S 50"


def test_dob_valid():
    assert normalize_date("13/08/2002", "dob") == "13/08/2002"


def test_dob_impossible_day_rejected_not_guessed():
    assert normalize_date("73/08/2002", "dob") is None


def test_dob_letters_in_digit_slots():
    assert normalize_date("I3/O8/2OO2", "dob") == "13/08/2002"


def test_dob_future_rejected():
    assert normalize_date("01/01/2999", "dob") is None


def test_name_strips_labels_and_noise():
    assert normalize_name("SURNAME CHIKOMBA,") == "CHIKOMBA"


def test_name_rejects_digit_garbage():
    assert normalize_name("63-2316316 $ 50") is None


def R(text, engine="tesseract", variant="flat", conf=0.9):
    return Reading(text, conf, engine, variant)


def test_vote_valid_reading_beats_invalid_one():
    dob = lambda r: normalize_date(r, "dob")
    out = vote([R("73/08/2002"), R("13/08/2002", "paddle"), R("13/08/2002", variant="clahe")], dob, W)
    assert out.value == "13/08/2002" and out.votes == 2 and not out.conflict
    assert out.agreement == pytest.approx(2 / 3)


def test_vote_flags_conflicting_valid_values():
    dob = lambda r: normalize_date(r, "dob")
    out = vote([R("13/08/2002"), R("18/08/2002", "paddle")], dob, W)
    assert out.conflict


def test_vote_nothing_valid():
    out = vote([R("garbage")], normalize_zw_id, W)
    assert out.value is None and out.votes == 0
