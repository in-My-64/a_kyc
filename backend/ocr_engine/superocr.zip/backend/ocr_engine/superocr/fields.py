"""
Field specs for the Zimbabwe National Registration card.

Every `normalize_*` function returns a CANONICAL, VALIDATED string or None.
Voting happens on canonical values, so "63-2316316 $ 50" and "632316316S50"
count as the same vote, and anything that can't be a valid value counts as none.

Repairs are position-aware: we know which slots are digits and which is the
letter, so O->0 is applied in digit slots only. No blind global swaps.
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from datetime import date, datetime
from typing import Callable

DIGIT_FIX = {"O": "0", "Q": "0", "D": "0", "I": "1", "L": "1", "Z": "2",
             "S": "5", "$": "5", "§": "5", "G": "6", "T": "7", "B": "8"}
LETTER_FIX = {"0": "O", "1": "I", "5": "S", "$": "S", "§": "S", "8": "B", "2": "Z", "6": "G"}
NAME_FIX = {"0": "O", "1": "I", "5": "S", "8": "B", "$": "S"}
LABEL_WORDS = {"SURNAME", "FIRST", "NAME", "DATE", "BIRTH", "VILLAGE", "ORIGIN",
               "PLACE", "ISSUE", "OF", "ID", "NUMBER"}


def _fix(ch: str, kind: str) -> str | None:
    if kind == "D":
        return ch if ch.isdigit() else DIGIT_FIX.get(ch)
    return ch if ch.isalpha() else LETTER_FIX.get(ch)


def normalize_zw_id(raw: str) -> str | None:
    """NN-NNNNNNN L NN (6-digit body accepted). Missing suffix => rejected."""
    s = re.sub(r"[^A-Z0-9$§]", "", raw.upper())
    for body in (7, 6):
        if len(s) == 2 + body + 1 + 2:
            kinds = "D" * (2 + body) + "L" + "DD"
            fixed = [_fix(c, k) for c, k in zip(s, kinds)]
            if None in fixed:
                return None
            f = "".join(fixed)
            return f"{f[:2]}-{f[2:2 + body]} {f[2 + body]} {f[-2:]}"
    return None


def normalize_date(raw: str, kind: str) -> str | None:
    """Canonical DD/MM/YYYY. kind: 'dob' (0-120y old) or 'issue' (not in the future)."""
    s = re.sub(r"[^A-Z0-9]", "", raw.upper())   # separators are noise; drop them
    if len(s) != 8:
        return None
    digits = [_fix(c, "D") for c in s]
    if None in digits:
        return None
    try:
        dt = datetime.strptime("".join(digits), "%d%m%Y").date()
    except ValueError:
        return None
    today = date.today()
    if kind == "dob" and not (0 <= (today - dt).days / 365.25 <= 120):
        return None
    if kind == "issue" and dt > today:
        return None
    return dt.strftime("%d/%m/%Y")


def normalize_name(raw: str) -> str | None:
    alnum = re.findall(r"[A-Z0-9$]", raw.upper())
    if not alnum or sum(c.isdigit() or c == "$" for c in alnum) / len(alnum) > 0.25:
        return None  # mostly digits: this is not a name, don't "repair" it into one
    s = "".join(NAME_FIX.get(c, c) for c in raw.upper())
    tokens = [t for t in re.findall(r"[A-Z][A-Z'\-]*", s) if len(t) >= 2 and t not in LABEL_WORDS]
    return " ".join(tokens) or None


@dataclass(frozen=True)
class FieldSpec:
    name: str
    normalize: Callable[[str], str | None]
    whitelist: str
    layout: tuple[float, float, float, float]  # fallback box, fractions of the dewarped card
    min_votes: int = 1                         # critical fields need agreement across reads


_DIG = "0123456789/.-"
_ALNUM = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ-"
_ALPHA = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz'-"

# Layout boxes are SEED values estimated from one photo. Tune them with the debug overlay.
ZW_NATIONAL_ID: dict[str, FieldSpec] = {s.name: s for s in (
    FieldSpec("id_number", normalize_zw_id, _ALNUM, (0.50, 0.20, 0.96, 0.28), min_votes=2),
    FieldSpec("surname", normalize_name, _ALPHA, (0.50, 0.26, 0.96, 0.34)),
    FieldSpec("first_name", normalize_name, _ALPHA, (0.50, 0.32, 0.96, 0.40)),
    FieldSpec("dob", lambda r: normalize_date(r, "dob"), _DIG, (0.50, 0.38, 0.96, 0.46), min_votes=2),
    FieldSpec("village_of_origin", normalize_name, _ALPHA, (0.50, 0.44, 0.96, 0.52)),
    FieldSpec("place_of_birth", normalize_name, _ALPHA, (0.50, 0.51, 0.96, 0.59)),
    FieldSpec("date_of_issue", lambda r: normalize_date(r, "issue"), _DIG, (0.50, 0.58, 0.96, 0.66)),
)}
