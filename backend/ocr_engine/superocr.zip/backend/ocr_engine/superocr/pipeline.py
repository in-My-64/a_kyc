from __future__ import annotations

import logging
import os
import time
from dataclasses import dataclass
from typing import Callable, Iterable, Optional

import cv2
import numpy as np

from .detect import Detector
from .dewarp import CARD_H, CARD_W, dewarp, find_card_quad
from .engines.base import OCREngine
from .enhance import prepare_crop, quality, variants
from .fields import ZW_NATIONAL_ID, FieldSpec
from .types import Box, CardResult, Detection, FieldResult, Reading
from .vote import VoteOutcome, vote

log = logging.getLogger(__name__)

Fallback = Callable[[np.ndarray, FieldSpec], Optional[str]]


@dataclass
class PipelineConfig:
    early_exit: float = 0.75
    min_blur: float = 60.0
    max_glare: float = 0.08
    pad_px: int = 6


def _best(dets: Iterable[Detection], label: str) -> Detection | None:
    return max((d for d in dets if d.label == label), key=lambda d: d.conf, default=None)


class SuperOCR:
    def __init__(self, detector: Detector, engines: list[OCREngine],
                 specs: dict[str, FieldSpec] | None = None, config: PipelineConfig | None = None,
                 fallback: Fallback | None = None, debug_dir: str | None = None):
        self.detector = detector
        self.engines = engines
        self.specs = specs or ZW_NATIONAL_ID
        self.cfg = config or PipelineConfig()
        self.fallback = fallback
        self.debug_dir = debug_dir
        self.weights = {e.name: e.weight for e in engines}
        self.weights["fallback"] = 1.0

    def run(self, image: np.ndarray) -> CardResult:
        issues: list[str] = []
        card, found = self._extract_card(image)
        if not found:
            issues.append("card_not_found")
        card, dets = self._orient(card)

        q = quality(card)
        if q["blur"] < self.cfg.min_blur:
            issues.append("image_blurry")
        if q["glare"] > self.cfg.max_glare:
            issues.append("image_glare")

        vs = variants(card)
        h, w = card.shape[:2]
        fields: dict[str, FieldResult] = {}
        boxes: dict[str, Box] = {}
        for spec in self.specs.values():
            det = _best(dets, spec.name)
            if det:
                box, source = det.box.padded(self.cfg.pad_px, w, h), "yolo"
            else:
                box, source = Box.from_fractions(spec.layout, w, h), "layout"
            boxes[spec.name] = box
            fields[spec.name] = self._read_field(spec, box, source, vs, card)

        if self.debug_dir:
            self._debug(card, boxes, fields)
        return CardResult(fields=fields, issues=issues, card_found=found, quality=q)

    def _extract_card(self, image: np.ndarray) -> tuple[np.ndarray, bool]:
        region = image
        det = _best(self.detector.detect(image), "card")
        if det:
            h, w = image.shape[:2]
            region = det.box.padded(int(0.03 * max(h, w)), w, h).crop(image)
        quad = find_card_quad(region)
        if quad is not None:
            return dewarp(region, quad), True
        return cv2.resize(region, (CARD_W, CARD_H), interpolation=cv2.INTER_CUBIC), det is not None

    def _orient(self, card: np.ndarray) -> tuple[np.ndarray, list[Detection]]:
        """The holder photo sits on the left; if YOLO finds it on the right, the card is upside down."""
        dets = self.detector.detect(card)
        photo = _best(dets, "photo")
        if photo and (photo.box.x1 + photo.box.x2) / 2 > card.shape[1] / 2:
            card = cv2.rotate(card, cv2.ROTATE_180)
            dets = self.detector.detect(card)
        return card, dets

    def _read_field(self, spec: FieldSpec, box: Box, source: str,
                    vs: dict[str, np.ndarray], card: np.ndarray) -> FieldResult:
        readings: list[Reading] = []
        out = VoteOutcome(None, 0.0, 0.0, 0, False)
        need = max(2, spec.min_votes)

        for vname, img in vs.items():
            crop = prepare_crop(box.crop(img))
            for eng in self.engines:
                try:
                    raw = eng.read(crop, spec.whitelist)
                except Exception:
                    log.exception("engine %s failed on %s/%s", eng.name, spec.name, vname)
                    continue
                readings.append(Reading(raw.text, raw.conf, eng.name, vname))
            out = vote(readings, spec.normalize, self.weights)
            if out.value and out.votes >= need and out.agreement >= self.cfg.early_exit and not out.conflict:
                break

        weak = out.value is None or out.conflict or out.votes < spec.min_votes
        if weak and self.fallback:
            try:
                text = self.fallback(box.crop(card), spec)
            except Exception:
                log.exception("fallback failed on %s", spec.name)
                text = None
            if text:
                readings.append(Reading(text, 0.5, "fallback", "card"))
                out = vote(readings, spec.normalize, self.weights)

        issues: list[str] = []
        if out.value is None:
            issues.append(f"{spec.name}_unreadable")
        else:
            if out.votes < spec.min_votes:
                issues.append(f"{spec.name}_low_agreement")
            if out.conflict:
                issues.append(f"{spec.name}_conflicting_readings")

        return FieldResult(name=spec.name, value=out.value, agreement=out.agreement,
                           confidence=out.confidence, votes=out.votes, source=source,
                           readings=readings, issues=issues)

    def _debug(self, card: np.ndarray, boxes: dict[str, Box], fields: dict[str, FieldResult]) -> None:
        # NOTE: these images contain PII. Enable only in dev.
        os.makedirs(self.debug_dir, exist_ok=True)
        vis = card.copy()
        for name, b in boxes.items():
            colour = (0, 180, 0) if fields[name].value else (0, 0, 255)
            cv2.rectangle(vis, (b.x1, b.y1), (b.x2, b.y2), colour, 2)
            cv2.putText(vis, f"{name}:{fields[name].value or '?'}", (b.x1, max(14, b.y1 - 4)),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.5, colour, 1)
        cv2.imwrite(os.path.join(self.debug_dir, f"card_{int(time.time() * 1000)}.png"), vis)
