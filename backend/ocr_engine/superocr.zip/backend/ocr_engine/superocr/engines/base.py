from __future__ import annotations

from typing import Protocol

import numpy as np

from ..types import RawRead


class OCREngine(Protocol):
    name: str
    weight: float

    def read(self, image: np.ndarray, whitelist: str | None = None) -> RawRead:
        """Read ONE line of text from a small crop."""
        ...
