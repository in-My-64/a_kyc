from __future__ import annotations

from statistics import mean

import numpy as np
import pytesseract
from pytesseract import Output

from ..types import RawRead


class TesseractEngine:
    """Needs Tesseract >= 4.1 so the LSTM engine honours the character whitelist."""

    name = "tesseract"

    def __init__(self, weight: float = 1.0, lang: str = "eng"):
        self.weight, self.lang = weight, lang

    def read(self, image: np.ndarray, whitelist: str | None = None) -> RawRead:
        cfg = "--oem 1 --psm 7"
        if whitelist:
            cfg += f" -c tessedit_char_whitelist={whitelist}"
        d = pytesseract.image_to_data(image, lang=self.lang, config=cfg, output_type=Output.DICT)
        words = [(w, float(c)) for w, c in zip(d["text"], d["conf"]) if w.strip() and float(c) >= 0]
        if not words:
            return RawRead("", 0.0)
        return RawRead(" ".join(w for w, _ in words), mean(c for _, c in words) / 100.0)
