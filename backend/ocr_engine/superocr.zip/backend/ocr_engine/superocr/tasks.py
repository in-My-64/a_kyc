"""
Celery entrypoint that wires SuperOCR into the existing document pipeline.

Drop-in replacement for the old `classify_document`: same signature, same
side effect (saves a ParsedDocument), same retry behaviour. Needs the raw
image, not just OCR text, so it reads straight from the document's file
field instead of an existing OCRResult.
"""
from __future__ import annotations

import cv2
import numpy as np
from celery import shared_task

from backend.core.tasks import WorkflowTrackingTask
from backend.core.workflow import mark_step
from backend.ocr_engine.models import OCRResult

from ..models import ParsedDocument
from .adapter import apply_to_parsed
from .factory import get_engine

_TRANSIENT = (OSError,)


def _load_image(document) -> np.ndarray:
    data = document.file.read()
    img = cv2.imdecode(np.frombuffer(data, np.uint8), cv2.IMREAD_COLOR)
    if img is None:
        raise ValueError(f"could not decode image for document {document.id}")
    return img


@shared_task(
    bind=True,
    base=WorkflowTrackingTask,
    autoretry_for=_TRANSIENT,
    retry_backoff=True,
    retry_jitter=True,
    max_retries=3,
)
def classify_document_v2(self, ocr_result_id, tracking_id=None):
    mark_step(tracking_id, "classify_document_v2", self.request.id)

    try:
        ocr = OCRResult.objects.select_related("document").get(id=ocr_result_id)
    except OCRResult.DoesNotExist as exc:
        raise ValueError(f"OCRResult {ocr_result_id} does not exist") from exc

    parsed, _ = ParsedDocument.objects.get_or_create(
        ocr_result=ocr,
        defaults={"doc_type": getattr(ocr.document, "doc_type", "unknown") or "unknown"},
    )

    image = _load_image(ocr.document)
    result = get_engine().run(image)
    issues = apply_to_parsed(parsed, result)

    if not parsed.id_number and not parsed.name:
        issues.append("extraction_empty: no id_number and no name extracted")

    parsed.verification_issues = issues
    parsed.save(update_fields=[
        "doc_type", "id_number", "name", "dob", "expiry", "nationality",
        "corrections", "verification_issues", "updated_at",
    ])
    return parsed.id
